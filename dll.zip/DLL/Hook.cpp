#include <windows.h>


HHOOK WINAPI MouseHook_Install(HWND objHWND);
void WINAPI MouseHook_Remove();
LRESULT CALLBACK MouseHook_Proc(int nCode, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK ShellHook_Proc(int nCode, WPARAM wParam, LPARAM lParam);
HHOOK WINAPI ShellHook_Install(HWND objHWND);
void WINAPI ShellHook_Remove();


#pragma data_seg(".SHARDAT")
	HWND		m_hHwnd = NULL;
	HHOOK		m_hHook = NULL;
	HWND		s_hHwnd = NULL;
	HHOOK		s_hHook = NULL;
#pragma data_seg()

extern HINSTANCE hInst;
void Errors(LPSTR apiFunction);



HHOOK WINAPI MouseHook_Install(HWND objHWND)
{
	m_hHwnd = objHWND;
	
	m_hHook = SetWindowsHookEx(WH_MOUSE, (HOOKPROC)MouseHook_Proc, hInst, 0);
	//if (m_hHook == NULL) Errors("SetWindowsHookEx");

	return m_hHook;
}

void WINAPI MouseHook_Remove()
{
	//if (UnhookWindowsHookEx(m_hHook) == 0) Errors("UnhookWindowsHookEx");
	UnhookWindowsHookEx(m_hHook);
}

LRESULT CALLBACK MouseHook_Proc(int nCode, WPARAM wParam, LPARAM lParam)
{	
	if (nCode < 0)
	{
		return CallNextHookEx(m_hHook, nCode, wParam, lParam);
	}

	if (nCode == HC_ACTION)
	{
		if ((wParam >= 0xA0) & (wParam <= 0xA9))
		{
			wParam = wParam + 352;
		}
		
		/*switch (wParam)
		{
			case WM_LBUTTONUP:
				PostMessage(m_hHwnd, wParam, 0, MAKEWPARAM(
				((MOUSEHOOKSTRUCT*) lParam)->pt.x,
				((MOUSEHOOKSTRUCT*) lParam)->pt.y));
				
				break;

			case WM_MBUTTONUP:
				PostMessage(m_hHwnd, wParam, 0, MAKEWPARAM(
				((MOUSEHOOKSTRUCT*) lParam)->pt.x,
				((MOUSEHOOKSTRUCT*) lParam)->pt.y));
				
				break;

			case WM_RBUTTONUP:
				PostMessage(m_hHwnd, wParam, 0, MAKEWPARAM(
				((MOUSEHOOKSTRUCT*) lParam)->pt.x,
				((MOUSEHOOKSTRUCT*) lParam)->pt.y));
				
				break;

			case WM_MOUSEMOVE:
				PostMessage(m_hHwnd, wParam, 0, MAKEWPARAM(
				((MOUSEHOOKSTRUCT*) lParam)->pt.x,
				((MOUSEHOOKSTRUCT*) lParam)->pt.y));

				break;
		}
		*/

		PostMessage(m_hHwnd, wParam, 0, MAKEWPARAM(
		((MOUSEHOOKSTRUCT*) lParam)->pt.x,
		((MOUSEHOOKSTRUCT*) lParam)->pt.y));
	}

	return 0;
}



HHOOK WINAPI ShellHook_Install(HWND objHWND)
{
	s_hHwnd = objHWND;

	s_hHook = SetWindowsHookEx(WH_SHELL, (HOOKPROC)ShellHook_Proc, hInst, 0);
	//if (s_hHook == NULL) Errors("SetWindowsHookEx");
	
	return s_hHook;
}


void WINAPI ShellHook_Remove()
{
	if (UnhookWindowsHookEx(s_hHook) == 0) Errors("UnhookWindowsHookEx");
}

LRESULT CALLBACK ShellHook_Proc(int nCode, WPARAM wParam, LPARAM lParam)
{	
	CallNextHookEx(s_hHook, nCode, wParam, lParam);
	//if (PostMessage(s_hHwnd, nCode, wParam, lParam) == 0) Errors("PostMessage");
	PostMessage(s_hHwnd, nCode, wParam, lParam);

	return 0;
}
