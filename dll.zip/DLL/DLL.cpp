#include <windows.h>
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>

HINSTANCE hInst;
bool bError;

//void _stdcall vbcall(long (_stdcall *lpcallback)(long i));

//msvcrt
LPSTR _stdcall ltoa_(long value, int radix, LPSTR buffer);
LPSTR _stdcall ultoa_(unsigned long value, int radix, LPSTR buffer);
long _stdcall strtol_(const char* ptr, int base);
unsigned long _stdcall strtoul_(const char* ptr, int base);

short _stdcall typecast_int32_int16(unsigned long int32);

//other
int _stdcall inp_(unsigned short port);
unsigned short _stdcall inpw_(unsigned short port);
int _stdcall outp_(unsigned short port, int data);
unsigned short _stdcall outpw_(unsigned short port, unsigned short data);

USHORT _stdcall checksum(USHORT *buffer, int size);

void Errors(LPSTR apiFunction);


//void _stdcall vbcall(long (_stdcall *lpcallback)(long i))
//{
//	lpcallback(10);
//}

LPSTR _stdcall ltoa_(long value, int radix, LPSTR buffer)
{
	char cbuffer[33];
	ltoa(value, cbuffer, radix);
	
	
    if (strlen(buffer) >= strlen(cbuffer))
    {
		strcpy(buffer, cbuffer);
	}

	return buffer;
}

LPSTR _stdcall ultoa_(unsigned long value, int radix, LPSTR buffer)
{
	char cbuffer[33];
	ultoa(value, cbuffer, radix);
	
	
    if (strlen(buffer) >= strlen(cbuffer))
    {
		strcpy(buffer, cbuffer);
	}

	return buffer;
}


long _stdcall strtol_(const char* ptr, int base)
{
	return strtol(ptr, NULL, base);
}

unsigned long _stdcall strtoul_(const char* ptr, int base)
{
	return strtoul(ptr, NULL, base);
}



short _stdcall typecast_int32_int16(unsigned long int32)
{
	return (short)int32;
}


int _stdcall inp_(unsigned short port)
{
	return inp(port);
}

unsigned short _stdcall inpw_(unsigned short port)
{
	return inpw(port);
}

int _stdcall outp_(unsigned short port, int data)
{
	return outp(port, data);
}

unsigned short _stdcall outpw_(unsigned short port, unsigned short data)
{
	return outpw(port, data);
}



USHORT _stdcall checksum(USHORT *buffer, int size)
{
  unsigned long cksum=0;

  while(size >1) {
	cksum+=*buffer++;
	size -=sizeof(USHORT);
  }
  
  if(size ) {
	cksum += *(UCHAR*)buffer;
  }

  cksum = (cksum >> 16) + (cksum & 0xffff);
  cksum += (cksum >>16);
  return (USHORT)(~cksum);
}



BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID) 
{
	if (fdwReason == DLL_PROCESS_ATTACH) 
	{
		if (DisableThreadLibraryCalls(hinstDLL) == 0) Errors("DisableThreadLibraryCalls");
		hInst = hinstDLL;
	}
	
	bError = false;
	return TRUE;
}