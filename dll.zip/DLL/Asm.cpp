#include <windows.h>


//Asm
void _stdcall cpuid_(long inpEAX, long *outEAX, long *outEBX, long *outECX, long *outEDX);
void _stdcall rdtsc_(ULARGE_INTEGER *tsc);


void _stdcall cpuid_(long inpEAX, long *outEAX, long *outEBX, long *outECX, long *outEDX)
{
	long lngEAX;
	long lngEBX;
	long lngECX;
	long lngEDX;
	
	_asm
	{
		mov		eax, inpEAX
		cpuid
		
		mov		lngEAX, eax
		mov		lngEBX, ebx
		mov		lngECX, ecx
		mov		lngEDX, edx
	}
	
	*outEAX = lngEAX;
	*outEBX = lngEBX;
	*outECX = lngECX;
	*outEDX = lngEDX;
}

void _stdcall rdtsc_(ULARGE_INTEGER *tsc)
{
	ULARGE_INTEGER t_tsc;
	_asm
	{
		rdtsc
		mov t_tsc.HighPart,edx
		mov t_tsc.LowPart,eax
	}

	*tsc = t_tsc;
}
