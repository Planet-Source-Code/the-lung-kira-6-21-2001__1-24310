#include <windows.h>


void Errors(LPSTR apiFunction);
extern bool bError;


//Functions

void Errors(LPSTR apiFunction)
{
	LPSTR errDescription = "";
	unsigned long apiError = 0;

	apiError = GetLastError();
    FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_FROM_SYSTEM, NULL, apiError, 0, errDescription, 2048, NULL);
    
    if (strcmp(errDescription, NULL) == 0)
	{
		errDescription = "No description available.";
	}
    
	if (bError == true)
	{
		MessageBox(NULL, errDescription, apiFunction, MB_OK);
	}
}