#include <windows.h>
#include <windowsx.h>


//Macros
int _stdcall GET_X_LPARAM_(LPARAM lParam);
int _stdcall GET_Y_LPARAM_(LPARAM lParam);
BYTE _stdcall HI_BYTE(WORD wValue);
WORD _stdcall HI_WORD(DWORD dwValue);
BYTE _stdcall LO_BYTE(WORD wValue);
WORD _stdcall LO_WORD(DWORD dwValue);
DWORD _stdcall MAKE_LONG(WORD wLow, WORD wHigh);
LPARAM _stdcall MAKE_LPARAM(WORD wLow, WORD wHigh);
WORD _stdcall MAKE_WORD(BYTE bLow, BYTE bHigh);
WPARAM _stdcall MAKE_WPARAM(WORD wLow, WORD wHigh);
LPTSTR _stdcall MAKE_INTRESOURCE(WORD wInteger);


int _stdcall GET_X_LPARAM_(LPARAM lParam)
{
	return GET_X_LPARAM(lParam);
}

int _stdcall GET_Y_LPARAM_(LPARAM lParam)
{
	return GET_Y_LPARAM(lParam);
}

BYTE _stdcall HI_BYTE(WORD wValue)
{
	return HIBYTE(wValue);
}

WORD _stdcall HI_WORD(DWORD dwValue)
{
	return HIWORD(dwValue);
}

BYTE _stdcall LO_BYTE(WORD wValue)
{
	return LOBYTE(wValue);
}

WORD _stdcall LO_WORD(DWORD dwValue)
{
	return LOWORD(dwValue);
}

DWORD _stdcall MAKE_LONG(WORD wLow, WORD wHigh)
{
	return MAKELONG(wLow, wHigh);
}

LPARAM _stdcall MAKE_LPARAM(WORD wLow, WORD wHigh)
{
	return MAKELPARAM(wLow, wHigh);
}

WORD _stdcall MAKE_WORD(BYTE bLow, BYTE bHigh)
{
	return MAKEWORD(bLow, bHigh);
}

WPARAM _stdcall MAKE_WPARAM(WORD wLow, WORD wHigh)
{
	return MAKEWPARAM(wLow, wHigh);
}

LPTSTR _stdcall MAKE_INTRESOURCE(WORD wInteger)
{
	return MAKEINTRESOURCE(wInteger);
}